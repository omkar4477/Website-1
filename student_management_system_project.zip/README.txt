
Student Management System - Flask

Run Steps:
1. Install Python
2. Install libraries:
   pip install flask reportlab
3. Run:
   python app.py
4. Open browser:
   http://127.0.0.1:5000
