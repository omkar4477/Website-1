
from flask import Flask, render_template, request, redirect, send_file
import sqlite3
from reportlab.pdfgen import canvas

app = Flask(__name__)

def get_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def login():
    return render_template("login.html")

@app.route('/dashboard')
def dashboard():
    conn=get_db()
    students=conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    attendance=conn.execute("SELECT COUNT(*) FROM attendance").fetchone()[0]
    return render_template("dashboard.html",students=students,attendance=attendance)

@app.route('/add_student',methods=['GET','POST'])
def add_student():
    if request.method=='POST':
        name=request.form['name']
        class_name=request.form['class']
        email=request.form['email']
        phone=request.form['phone']
        conn=get_db()
        conn.execute("INSERT INTO students(name,class,email,phone) VALUES(?,?,?,?)",
                     (name,class_name,email,phone))
        conn.commit()
        return redirect('/students')
    return render_template("add_student.html")

@app.route('/students')
def students():
    conn=get_db()
    data=conn.execute("SELECT * FROM students").fetchall()
    return render_template("students.html",students=data)

@app.route('/delete/<int:id>')
def delete(id):
    conn=get_db()
    conn.execute("DELETE FROM students WHERE id=?",(id,))
    conn.commit()
    return redirect('/students')

@app.route('/report')
def report():
    file="students_report.pdf"
    c=canvas.Canvas(file)
    conn=get_db()
    students=conn.execute("SELECT * FROM students").fetchall()
    y=800
    for s in students:
        text=f"{s['id']}  {s['name']}  {s['class']}"
        c.drawString(100,y,text)
        y-=20
    c.save()
    return send_file(file,as_attachment=True)

if __name__=="__main__":
    app.run(debug=True)
